const AWS = require('aws-sdk');
const docClient = new AWS.DynamoDB.DocumentClient({region: 'eu-north-1'});

/**
 * Fuction responisble for storing and retriving data from database.
 * 
 * TableName in database should be called Domains and and entry should
 * have the folowing attributes:
 *	domain {String} (Primary key)
 *	ip 	   {String}
 *	expire {int}
 *
 */
 

'use strict';


exports.handler = async (event, context) => {

    const response = {
        statusCode: 400,
        body: JSON.stringify('MISSING domain INPUT'),
        context: context
    };
    
    if (event.http_method === 'GET') {
        
         if (!event.domain) {
            response.body = JSON.stringify('Bad input, missing parameter');
         } else {
            
             response.body = JSON.stringify('GET request...');
             
             await handleGet(event).then((data) => {
                 response.statusCode = 200;
                 response.body = data;
             }).catch((err) => {
                 response.statusCode = 400;
                 response.body = err;
             });
         } 
        
        
        //
    } else if (event.http_method === 'POST') {
        
        if (!event.domain || !event.ip || !event.ttl) {
            response.body = JSON.stringify('Bad input, missing parameter');
        } else {
            handlePost(event.domain, event.ip, event.ttl);
            response.statusCode = 200;
            response.body = JSON.stringify('POST request...');
            const cloudwatchLogInfo = {
                event: "POST",
                date: Date.now(),
                context: context,
            }
            console.info(cloudwatchLogInfo);
        }
        
    } else if (event.http_method === 'DELETE' && false) {
        if (!event.password || event.password !== 'truncate') {
            response.statusCode = 400;
            response.body = JSON.stringify('Invalid password: ' + event.password);
        } else {
            response.statusCode = 200;
            response.body = JSON.stringify('DELETE request...');
            await handlePost(event);
        }
    } else {
        response.statusCode = 400;
        response.body = JSON.stringify('Impossible call ' + event.http_method);
    }
    

    return response;
    
};

/**
 * stores data in database.
 * @param {String} domain the domain to store in database (Primary key)
 * @param {String} ip a IP belonging to the domain
 * @param {int} ttl the time to live accociated with the domain.
 * @return {JSON} error on error.
 */
async function handlePost(domain, ip, ttl) {
    
    return  new Promise((resolve, reject) => {
    
        var params = {
            Item: {
                Domain: domain,
                ip: ip,
                expire: Date.now() + ttl
            },
            TableName: 'Domains'
        };
        
            docClient.put(params, (err, data) => {
            if (err) {
                console.info("err = " + err);
                reject(err);
            } 
            else {
                console.info("data = " + data);
                resolve(data);
               
            }
        });
    });    
}

/**
 * gets data from database.
 * @param {JSON} event with domain name
 * @return {JSON} ip of domain if cashed.
 */
function handleGet(event) {
    
    return  new Promise((resolve, reject) => {
        
        var params = {
            
            TableName : 'Domains',
            Key: {
                 Domain: event.domain
            }
        };
        
            docClient.get(params, (err, data) => {
            if (err) {
                reject(err);
            } 
            else {
                if ((Object.keys(data).length === 0 && data.constructor === Object) || data.Item.expire <= Date.now()) {
                    resolve({});
                }
                else {
                    resolve(data);
                }
            }
        });
        
    });
}

/**
 * Truncates all entries in database.
 * @param {JSON} event with domain name
 * @return {JSON} deleted events.
 */
function handleDelete(event) {
    
    return  scanTable('Domains');
}

async function scanTable(tableName) {
    const params = {
        TableName: tableName
    };

    let scanResults = [];
    let items;
    do {
        items =  await docClient.scan(params).promise();
        items.Items.forEach((item) => scanResults.push(item));
        params.ExclusiveStartKey  = items.LastEvaluatedKey;
    } while (typeof items.LastEvaluatedKey != "undefined");

    return scanResults;

};