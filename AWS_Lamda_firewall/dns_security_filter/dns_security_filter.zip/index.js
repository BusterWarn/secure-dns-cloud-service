/**
 * returns information if domain is considered safe.
 * @param {String} ip the ip of the url to check safety on
 * @return {JSON} information on the domain. body of JSON will cointain a score
 * between 0-100. 0 is considered unsafe and 100 is considered safe
 */

'use strict';
const Curl  = require( 'node-libcurl' ).Curl;
const curl = new Curl();

//opportunity to give a URL for a security filter
//curl.setOpt('URL', 'api for security filter');

curl.setOpt('FOLLOWLOCATION', true);
curl.setOpt('DEFAULT_PROTOCOL', 'HTTPS')
curl.setOpt('SSL_VERIFYPEER', false);



exports.handler = async (event, context) => {

    let response = {
        statusCode: 400,
        body: JSON.stringify('Missing IP address input'),
        context: context,
    };

    if (!event.ip) {
        return response;
    }

	//mock resulut
    await sleepFunc(10).then((data) => {
      response.body = {score: 95};
      response.statusCode = 200;
      
    });
	return response;

	
	//this block of code can be executed given that an api for that returnes a score
	//value is set in the top of the file
	
	/*
    await lookUp(event.ip).then((data) => {
      response.statusCode = 200;
      let reputation = JSON.parse(data).reputation;
      if (reputation < repThreshold) {
        response.body = false
      } else {
        response.body = true;
      }
    }).catch((err) => {
      response.statusCode = 400;
      response.body = err;
    });
    return response;	*/

};


async function sleepFunc(time) {

  return new Promise((resolve, reject) => {

    setTimeout(function () {
      resolve(true);
    }, time);
  });
}

/**
 * returns information if domain is considered safe.
 * @param {string} ip ip of the url to check safety on
 * @return {JSON} information on the domain from clavister risk scoring engine
 */
async function lookUp(ip) {
  let data = "{\"ip\": \"" + ip + "\" }";
  curl.setOpt('POSTFIELDS', data);

  return new Promise((resolve, reject) => {
    curl.perform()

    curl.on('end', function (statusCode, data, headers) {
      curl.close.bind(curl);
      resolve(data);
    });

    curl.on('error', function (err) {
      curl.close.bind(curl);
      reject(err);
    });

  });
}
