'use strict'
const {DNSoverTLS} = require('dohdec');
const cloudflareServer = '1.1.1.1';
const dot = new DNSoverTLS(cloudflareServer);


//type for lookup, 'A' = ipv4 address
const type = 'A'

exports.handler = async (event) => {

  if (!event.domain) {
    const response = {
        statusCode: 400,
        body: JSON.stringify('No domain name given'),
    };
    return response;
  }
  let domain = event.domain;


  try {

    //possibility to parse out execive data here
    //done at function caller at the moment

    let answer =  await queryTLS(domain);
    const response = {
    statusCode: 200,
    body: answer,
    };
    return response;
  } catch (err) {
    const error = {
      statusCode: 400,
      body: err,
    };
    return error;
  }



};

/**
 * Creates an async DNS query using DNS protocol over TLS.
 * @param {String} domain the url to do DNS UDP lookup for
 * @return {Promise} Proimse containging information from lookup.
 */
async function queryTLS(domain) {

  let data = await dot.lookup(domain, type);
  return data;
}
