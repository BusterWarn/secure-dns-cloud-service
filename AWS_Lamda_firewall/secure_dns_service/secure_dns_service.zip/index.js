'use strict';

const AWS = require('aws-sdk');
AWS.config.region = 'eu-north-1';

const lambda = new AWS.Lambda();


/**
 * controller function binding the others togheter.
 * @param {String} domain to get
 * @return {Promise} rejects on error, resolves with daomain address.
 */
exports.handler = async (event, context) => {


	//timestamps just used for testing and are in a confusing format.
	//can be removed
    let response = {
        statusCode: 400,
        body: JSON.stringify('Invalid input: domain'),
        source: JSON.stringify('Controller'),
        contexts: [],
        timestamps: {
            start: Date.now(),
            end: 0,
            cachestart: 0,
            cacheend: 0,
            lookupstart: 0,
            lookupend: 0,
            filterstart: 0,
            filterend: 0,
        }
    };
    
    response.contexts.push(context);

    if (!event.domain) {
        response.timestamps.end = Date.now();
        return response;
    }

    let domain = event.domain;

    response.timestamps.cachestart = Date.now();
    response.body = await getCache(domain).then((cached) => {
        response.timestamps.cacheend = Date.now();
        response.contexts.push(cached.context);
        
        // If empty object (no cahced domain)
        if ((Object.keys(cached.body).length === 0 && cached.body.constructor === Object)) {
            response.timestamps.lookupstart = Date.now();
			
			//external lookup
            return dnsLookUp(domain).then((data) => {
                response.timestamps.lookupend = Date.now();
                response.contexts.push(data.context);
                if (data.body.addresses.length === 0) {
                    response.statusCode = '400';
                    response.source = 'External DNS UDP lookup'
                    let body = 'Could not find address'
                    response.timestamps.end = Date.now();
                    return body;
                } else {
                    let ipaddress = data.body.addresses[0];
					//could get ttl from answer here

                    response.statusCode = '200';
                    response.source = 'External DNS UDP lookup';
                    response.timestamps.filterstart = Date.now();
					
					//advice domain filter
                    return domainFiltering(ipaddress).then((data) => {
                        response.timestamps.filterend = Date.now();
                        response.timestamps.end = Date.now();
                        response.contexts.push(data.context);
                        //cash
                        if (data.body.score > 20) {
                            cacheDomain(domain, ipaddress);
                            return ipaddress;
                        } else {
                            response.source = 'IP address filter';
                            return 'Site is considered unsafe';
                        }
                    });
                }
            });

        } else {
			//found in cash
            response.timestamps.cacheend = Date.now();
            response.timestamps.end = Date.now();
            response.statusCode = '200'
            response.source = 'Recived from cache'
            return cached.body.Item.ip;
        }
    }).catch((err) => {
		// should implement better error handeling to find the source
        response.statusCode= '500';
        response.source = 'Error occured in controller';
        response.timestamps.end = Date.now();
        if (response.timestamps.filterstart !== 0)
            response.timestamps.filterend = response.timestamps.end;
        return err;
    });
    
    return response;
};


/**
 * get domain address from external resolver.
 * @param {String} domain to get
 * @return {Promise} rejects on error, resolves with daomain address.
 */
 async function dnsLookUp(domain) {
        return  new Promise((resolve, reject) => {
        let domainFilteringfunc = 'dns_udp_query';
        let payLoad = '{ "domain" : "' + domain + '" }';

        let params = {
            FunctionName: domainFilteringfunc,
            InvocationType: 'RequestResponse',
            LogType: 'Tail',
            Payload: payLoad
        };

        lambda.invoke(params, function(err, data) {
            if (err) {
                reject(err);
            }
            else {
                let response = JSON.parse(data.Payload);
                resolve(response)
            }
        });
    });
 }


/**
 * get domain address if it is cached.
 * @param {String} domain to get
 * @return {Promise} rejects on error, resolves with daomain if cached
 * and false if not cached.
 */
async function getCache(domain) {
     return  new Promise((resolve, reject) => {
        let domainCachefunc = 'dns_caching';
        
        let payload = {
            domain: domain,
            http_method: 'GET'
        };
        
        payload = JSON.stringify(payload);

        let params = {
            FunctionName: domainCachefunc,
            InvocationType: 'RequestResponse',
            LogType: 'Tail',
            Payload: payload
        };

        lambda.invoke(params, function(err, data) {
            if (err) {
                reject(err);
            }
            else {
                let response = JSON.parse(data.Payload);
                resolve(response);
            }
        });
    });
}

/**
 * Checks if a domain is considered safe.
 * @param {String} domain to check
 * @return {Promise} that resolves when considered safe.
 */
async function domainFiltering(ip) {

    return  new Promise((resolve, reject) => {
        let domainFilteringfunc = 'dns_security_filter';
        let payLoad = '{ "ip" : "' + ip + '" }';

        let params = {
            FunctionName: domainFilteringfunc,
            InvocationType: 'RequestResponse',
            LogType: 'Tail',
            Payload: payLoad
        };

        lambda.invoke(params, function(err, data) {
            if (err) {
                reject(err);
            } else {
                resolve(JSON.parse(data.Payload));
            }
        });
    });
}


async function cacheDomain(domain, address) {
    
     return  new Promise((resolve, reject) => {
        let domainFilteringfunc = 'dns_caching';
        
        let payload = {
            domain: domain,
			// adds 10 seconds ttl, could preferably use ttl retrived from the lookup.
            ttl: 1000 * 60 * 10,
            ip: address,
            http_method: 'POST'
        };
        
        payload = JSON.stringify(payload);

        let params = {
            FunctionName: domainFilteringfunc,
            InvocationType: 'Event',
            LogType: 'Tail',
            Payload: payload
        };

        lambda.invoke(params, function(err, data) {
            if (err) {
                reject(err);
            } else {
                resolve(data);
            }
        });
    });
}